package com.llglh.wavesense.app.db

//用户数据
data class User (var id: Int = 0,var name: String = "",var password: String = "")